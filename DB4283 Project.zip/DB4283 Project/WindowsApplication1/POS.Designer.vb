﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class POS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.CalculateButton = New System.Windows.Forms.Button()
        Me.DrinksGroupBox = New System.Windows.Forms.GroupBox()
        Me.FivedayvideogameRadioButton = New System.Windows.Forms.RadioButton()
        Me.OneWeekvideogameRadioButton = New System.Windows.Forms.RadioButton()
        Me.VideogameQuantityTextBox = New System.Windows.Forms.TextBox()
        Me.ThreeDayVideogameRadioButton = New System.Windows.Forms.RadioButton()
        Me.VideogamePriceTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DessertsGroupBox = New System.Windows.Forms.GroupBox()
        Me.LateFeePriceTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LateMovieQuantityTextBox = New System.Windows.Forms.TextBox()
        Me.LateGameQuantityTextBox = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SaladsGroupBox = New System.Windows.Forms.GroupBox()
        Me.OneweekmovieButton = New System.Windows.Forms.RadioButton()
        Me.MoviePriceTextBox = New System.Windows.Forms.TextBox()
        Me.MovieQuantityTextBox = New System.Windows.Forms.TextBox()
        Me.ThreeDaymovieRadioButton = New System.Windows.Forms.RadioButton()
        Me.FivedaymovieRadioButton = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TotalPriceTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DaysLateTextBox = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.LateMovieCheckBox = New System.Windows.Forms.CheckBox()
        Me.LateGameCheckBox = New System.Windows.Forms.CheckBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DrinksGroupBox.SuspendLayout()
        Me.DessertsGroupBox.SuspendLayout()
        Me.SaladsGroupBox.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.name1
        Me.PictureBox1.Location = New System.Drawing.Point(222, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(743, 114)
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(615, 421)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 13
        Me.ClearButton.Text = "C&lear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'CalculateButton
        '
        Me.CalculateButton.Location = New System.Drawing.Point(491, 421)
        Me.CalculateButton.Name = "CalculateButton"
        Me.CalculateButton.Size = New System.Drawing.Size(75, 23)
        Me.CalculateButton.TabIndex = 12
        Me.CalculateButton.Text = "&Calculate"
        Me.CalculateButton.UseVisualStyleBackColor = True
        '
        'DrinksGroupBox
        '
        Me.DrinksGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.DrinksGroupBox.Controls.Add(Me.FivedayvideogameRadioButton)
        Me.DrinksGroupBox.Controls.Add(Me.OneWeekvideogameRadioButton)
        Me.DrinksGroupBox.Controls.Add(Me.VideogameQuantityTextBox)
        Me.DrinksGroupBox.Controls.Add(Me.ThreeDayVideogameRadioButton)
        Me.DrinksGroupBox.Controls.Add(Me.VideogamePriceTextBox)
        Me.DrinksGroupBox.Controls.Add(Me.Label5)
        Me.DrinksGroupBox.Controls.Add(Me.Label4)
        Me.DrinksGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.DrinksGroupBox.Location = New System.Drawing.Point(465, 158)
        Me.DrinksGroupBox.Name = "DrinksGroupBox"
        Me.DrinksGroupBox.Size = New System.Drawing.Size(250, 211)
        Me.DrinksGroupBox.TabIndex = 17
        Me.DrinksGroupBox.TabStop = False
        Me.DrinksGroupBox.Text = "Video Games"
        '
        'FivedayvideogameRadioButton
        '
        Me.FivedayvideogameRadioButton.AutoSize = True
        Me.FivedayvideogameRadioButton.Location = New System.Drawing.Point(6, 67)
        Me.FivedayvideogameRadioButton.Name = "FivedayvideogameRadioButton"
        Me.FivedayvideogameRadioButton.Size = New System.Drawing.Size(101, 17)
        Me.FivedayvideogameRadioButton.TabIndex = 23
        Me.FivedayvideogameRadioButton.TabStop = True
        Me.FivedayvideogameRadioButton.Text = "Five Day Rental"
        Me.FivedayvideogameRadioButton.UseVisualStyleBackColor = True
        '
        'OneWeekvideogameRadioButton
        '
        Me.OneWeekvideogameRadioButton.AutoSize = True
        Me.OneWeekvideogameRadioButton.Location = New System.Drawing.Point(4, 100)
        Me.OneWeekvideogameRadioButton.Name = "OneWeekvideogameRadioButton"
        Me.OneWeekvideogameRadioButton.Size = New System.Drawing.Size(111, 17)
        Me.OneWeekvideogameRadioButton.TabIndex = 23
        Me.OneWeekvideogameRadioButton.TabStop = True
        Me.OneWeekvideogameRadioButton.Text = "One Week Rental"
        Me.OneWeekvideogameRadioButton.UseVisualStyleBackColor = True
        '
        'VideogameQuantityTextBox
        '
        Me.VideogameQuantityTextBox.Location = New System.Drawing.Point(122, 135)
        Me.VideogameQuantityTextBox.Name = "VideogameQuantityTextBox"
        Me.VideogameQuantityTextBox.Size = New System.Drawing.Size(100, 20)
        Me.VideogameQuantityTextBox.TabIndex = 18
        Me.VideogameQuantityTextBox.Text = "0"
        '
        'ThreeDayVideogameRadioButton
        '
        Me.ThreeDayVideogameRadioButton.AutoSize = True
        Me.ThreeDayVideogameRadioButton.Location = New System.Drawing.Point(6, 35)
        Me.ThreeDayVideogameRadioButton.Name = "ThreeDayVideogameRadioButton"
        Me.ThreeDayVideogameRadioButton.Size = New System.Drawing.Size(109, 17)
        Me.ThreeDayVideogameRadioButton.TabIndex = 19
        Me.ThreeDayVideogameRadioButton.TabStop = True
        Me.ThreeDayVideogameRadioButton.Text = "Three Day Rental"
        Me.ThreeDayVideogameRadioButton.UseVisualStyleBackColor = True
        '
        'VideogamePriceTextBox
        '
        Me.VideogamePriceTextBox.Location = New System.Drawing.Point(122, 169)
        Me.VideogamePriceTextBox.Name = "VideogamePriceTextBox"
        Me.VideogamePriceTextBox.ReadOnly = True
        Me.VideogamePriceTextBox.Size = New System.Drawing.Size(100, 20)
        Me.VideogamePriceTextBox.TabIndex = 19
        Me.VideogamePriceTextBox.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 172)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Video Game Price:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 138)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Video Game Quantity:"
        '
        'DessertsGroupBox
        '
        Me.DessertsGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.DessertsGroupBox.Controls.Add(Me.LateGameCheckBox)
        Me.DessertsGroupBox.Controls.Add(Me.LateMovieCheckBox)
        Me.DessertsGroupBox.Controls.Add(Me.DaysLateTextBox)
        Me.DessertsGroupBox.Controls.Add(Me.LateFeePriceTextBox)
        Me.DessertsGroupBox.Controls.Add(Me.Label8)
        Me.DessertsGroupBox.Controls.Add(Me.Label9)
        Me.DessertsGroupBox.Controls.Add(Me.LateMovieQuantityTextBox)
        Me.DessertsGroupBox.Controls.Add(Me.LateGameQuantityTextBox)
        Me.DessertsGroupBox.Controls.Add(Me.Label7)
        Me.DessertsGroupBox.Controls.Add(Me.Label6)
        Me.DessertsGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.DessertsGroupBox.Location = New System.Drawing.Point(827, 158)
        Me.DessertsGroupBox.Name = "DessertsGroupBox"
        Me.DessertsGroupBox.Size = New System.Drawing.Size(250, 211)
        Me.DessertsGroupBox.TabIndex = 18
        Me.DessertsGroupBox.TabStop = False
        Me.DessertsGroupBox.Text = "Late Fees"
        '
        'LateFeePriceTextBox
        '
        Me.LateFeePriceTextBox.Location = New System.Drawing.Point(119, 169)
        Me.LateFeePriceTextBox.Name = "LateFeePriceTextBox"
        Me.LateFeePriceTextBox.ReadOnly = True
        Me.LateFeePriceTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LateFeePriceTextBox.TabIndex = 25
        Me.LateFeePriceTextBox.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 169)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(79, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Late Fee Price:"
        '
        'LateMovieQuantityTextBox
        '
        Me.LateMovieQuantityTextBox.Location = New System.Drawing.Point(119, 68)
        Me.LateMovieQuantityTextBox.Name = "LateMovieQuantityTextBox"
        Me.LateMovieQuantityTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LateMovieQuantityTextBox.TabIndex = 20
        Me.LateMovieQuantityTextBox.Text = "0"
        '
        'LateGameQuantityTextBox
        '
        Me.LateGameQuantityTextBox.Location = New System.Drawing.Point(119, 104)
        Me.LateGameQuantityTextBox.Name = "LateGameQuantityTextBox"
        Me.LateGameQuantityTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LateGameQuantityTextBox.TabIndex = 21
        Me.LateGameQuantityTextBox.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 107)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Late Game Quantity:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 71)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(105, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Late Movie Quantity:"
        '
        'SaladsGroupBox
        '
        Me.SaladsGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.SaladsGroupBox.Controls.Add(Me.OneweekmovieButton)
        Me.SaladsGroupBox.Controls.Add(Me.MoviePriceTextBox)
        Me.SaladsGroupBox.Controls.Add(Me.MovieQuantityTextBox)
        Me.SaladsGroupBox.Controls.Add(Me.ThreeDaymovieRadioButton)
        Me.SaladsGroupBox.Controls.Add(Me.FivedaymovieRadioButton)
        Me.SaladsGroupBox.Controls.Add(Me.Label3)
        Me.SaladsGroupBox.Controls.Add(Me.Label2)
        Me.SaladsGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.SaladsGroupBox.Location = New System.Drawing.Point(103, 158)
        Me.SaladsGroupBox.Name = "SaladsGroupBox"
        Me.SaladsGroupBox.Size = New System.Drawing.Size(250, 211)
        Me.SaladsGroupBox.TabIndex = 15
        Me.SaladsGroupBox.TabStop = False
        Me.SaladsGroupBox.Text = "Movies"
        '
        'OneweekmovieButton
        '
        Me.OneweekmovieButton.AutoSize = True
        Me.OneweekmovieButton.Location = New System.Drawing.Point(6, 100)
        Me.OneweekmovieButton.Name = "OneweekmovieButton"
        Me.OneweekmovieButton.Size = New System.Drawing.Size(111, 17)
        Me.OneweekmovieButton.TabIndex = 24
        Me.OneweekmovieButton.TabStop = True
        Me.OneweekmovieButton.Text = "One Week Rental"
        Me.OneweekmovieButton.UseVisualStyleBackColor = True
        '
        'MoviePriceTextBox
        '
        Me.MoviePriceTextBox.Location = New System.Drawing.Point(119, 169)
        Me.MoviePriceTextBox.Name = "MoviePriceTextBox"
        Me.MoviePriceTextBox.ReadOnly = True
        Me.MoviePriceTextBox.Size = New System.Drawing.Size(100, 20)
        Me.MoviePriceTextBox.TabIndex = 16
        Me.MoviePriceTextBox.Text = "0"
        '
        'MovieQuantityTextBox
        '
        Me.MovieQuantityTextBox.Location = New System.Drawing.Point(119, 131)
        Me.MovieQuantityTextBox.Name = "MovieQuantityTextBox"
        Me.MovieQuantityTextBox.Size = New System.Drawing.Size(100, 20)
        Me.MovieQuantityTextBox.TabIndex = 17
        Me.MovieQuantityTextBox.Text = "0"
        '
        'ThreeDaymovieRadioButton
        '
        Me.ThreeDaymovieRadioButton.AutoSize = True
        Me.ThreeDaymovieRadioButton.Location = New System.Drawing.Point(6, 35)
        Me.ThreeDaymovieRadioButton.Name = "ThreeDaymovieRadioButton"
        Me.ThreeDaymovieRadioButton.Size = New System.Drawing.Size(109, 17)
        Me.ThreeDaymovieRadioButton.TabIndex = 17
        Me.ThreeDaymovieRadioButton.TabStop = True
        Me.ThreeDaymovieRadioButton.Text = "Three Day Rental"
        Me.ThreeDaymovieRadioButton.UseVisualStyleBackColor = True
        '
        'FivedaymovieRadioButton
        '
        Me.FivedaymovieRadioButton.AutoSize = True
        Me.FivedaymovieRadioButton.Location = New System.Drawing.Point(6, 67)
        Me.FivedaymovieRadioButton.Name = "FivedaymovieRadioButton"
        Me.FivedaymovieRadioButton.Size = New System.Drawing.Size(101, 17)
        Me.FivedaymovieRadioButton.TabIndex = 16
        Me.FivedaymovieRadioButton.TabStop = True
        Me.FivedaymovieRadioButton.Text = "Five Day Rental"
        Me.FivedaymovieRadioButton.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 138)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Movie Quantity:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 172)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Movie Price:"
        '
        'TotalPriceTextBox
        '
        Me.TotalPriceTextBox.Location = New System.Drawing.Point(598, 474)
        Me.TotalPriceTextBox.Name = "TotalPriceTextBox"
        Me.TotalPriceTextBox.ReadOnly = True
        Me.TotalPriceTextBox.Size = New System.Drawing.Size(100, 20)
        Me.TotalPriceTextBox.TabIndex = 21
        Me.TotalPriceTextBox.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(482, 477)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Total Price:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1181, 24)
        Me.MenuStrip1.TabIndex = 23
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'DaysLateTextBox
        '
        Me.DaysLateTextBox.Location = New System.Drawing.Point(119, 135)
        Me.DaysLateTextBox.Name = "DaysLateTextBox"
        Me.DaysLateTextBox.Size = New System.Drawing.Size(100, 20)
        Me.DaysLateTextBox.TabIndex = 27
        Me.DaysLateTextBox.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 138)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(58, 13)
        Me.Label9.TabIndex = 26
        Me.Label9.Text = "Days Late:"
        '
        'LateMovieCheckBox
        '
        Me.LateMovieCheckBox.AutoSize = True
        Me.LateMovieCheckBox.Location = New System.Drawing.Point(10, 19)
        Me.LateMovieCheckBox.Name = "LateMovieCheckBox"
        Me.LateMovieCheckBox.Size = New System.Drawing.Size(79, 17)
        Me.LateMovieCheckBox.TabIndex = 28
        Me.LateMovieCheckBox.Text = "Late Movie"
        Me.LateMovieCheckBox.UseVisualStyleBackColor = True
        '
        'LateGameCheckBox
        '
        Me.LateGameCheckBox.AutoSize = True
        Me.LateGameCheckBox.Location = New System.Drawing.Point(10, 42)
        Me.LateGameCheckBox.Name = "LateGameCheckBox"
        Me.LateGameCheckBox.Size = New System.Drawing.Size(78, 17)
        Me.LateGameCheckBox.TabIndex = 29
        Me.LateGameCheckBox.Text = "Late Game"
        Me.LateGameCheckBox.UseVisualStyleBackColor = True
        '
        'POS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(1181, 540)
        Me.Controls.Add(Me.TotalPriceTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CalculateButton)
        Me.Controls.Add(Me.DrinksGroupBox)
        Me.Controls.Add(Me.DessertsGroupBox)
        Me.Controls.Add(Me.SaladsGroupBox)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "POS"
        Me.Text = "POS"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DrinksGroupBox.ResumeLayout(False)
        Me.DrinksGroupBox.PerformLayout()
        Me.DessertsGroupBox.ResumeLayout(False)
        Me.DessertsGroupBox.PerformLayout()
        Me.SaladsGroupBox.ResumeLayout(False)
        Me.SaladsGroupBox.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ClearButton As Button
    Friend WithEvents CalculateButton As Button
    Friend WithEvents DrinksGroupBox As GroupBox
    Friend WithEvents VideogameQuantityTextBox As TextBox
    Friend WithEvents VideogamePriceTextBox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents DessertsGroupBox As GroupBox
    Friend WithEvents LateMovieQuantityTextBox As TextBox
    Friend WithEvents LateGameQuantityTextBox As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents SaladsGroupBox As GroupBox
    Friend WithEvents MoviePriceTextBox As TextBox
    Friend WithEvents MovieQuantityTextBox As TextBox
    Friend WithEvents ThreeDaymovieRadioButton As RadioButton
    Friend WithEvents FivedaymovieRadioButton As RadioButton
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents FivedayvideogameRadioButton As RadioButton
    Friend WithEvents OneWeekvideogameRadioButton As RadioButton
    Friend WithEvents ThreeDayVideogameRadioButton As RadioButton
    Friend WithEvents OneweekmovieButton As RadioButton
    Friend WithEvents LateFeePriceTextBox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TotalPriceTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DaysLateTextBox As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents LateGameCheckBox As CheckBox
    Friend WithEvents LateMovieCheckBox As CheckBox
End Class
