﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Reports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LateGroupBox = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.OverdueItemsListBox = New System.Windows.Forms.ListBox()
        Me.LateFeeTotalTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.MoviesGroupBox = New System.Windows.Forms.GroupBox()
        Me.MovieDueTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MovieCheckOutTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.MovieRentedQtyTextBox = New System.Windows.Forms.TextBox()
        Me.MovieComboBox = New System.Windows.Forms.ComboBox()
        Me.MovieInStockQuantityTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GenreGroupBox = New System.Windows.Forms.GroupBox()
        Me.GenreInventoryComboBox = New System.Windows.Forms.ComboBox()
        Me.InventoryAmountTextBox = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CustomerGroupBox = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CustomerComboBox = New System.Windows.Forms.ComboBox()
        Me.VideoGameComboBox = New System.Windows.Forms.ComboBox()
        Me.VideoGamesGroupBox = New System.Windows.Forms.GroupBox()
        Me.GameDueTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GameCheckOutTextBox = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GameRentalQtyTextBox = New System.Windows.Forms.TextBox()
        Me.GameInStockTextBox = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LateGroupBox.SuspendLayout()
        Me.MoviesGroupBox.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GenreGroupBox.SuspendLayout()
        Me.CustomerGroupBox.SuspendLayout()
        Me.VideoGamesGroupBox.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LateGroupBox
        '
        Me.LateGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.LateGroupBox.Controls.Add(Me.Label4)
        Me.LateGroupBox.Controls.Add(Me.OverdueItemsListBox)
        Me.LateGroupBox.Controls.Add(Me.LateFeeTotalTextBox)
        Me.LateGroupBox.Controls.Add(Me.Label8)
        Me.LateGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.LateGroupBox.Location = New System.Drawing.Point(88, 417)
        Me.LateGroupBox.Name = "LateGroupBox"
        Me.LateGroupBox.Size = New System.Drawing.Size(261, 211)
        Me.LateGroupBox.TabIndex = 30
        Me.LateGroupBox.TabStop = False
        Me.LateGroupBox.Text = "Overdue Items/Late Fees Report"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 13)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Current Overdue Items:"
        '
        'OverdueItemsListBox
        '
        Me.OverdueItemsListBox.FormattingEnabled = True
        Me.OverdueItemsListBox.Location = New System.Drawing.Point(128, 94)
        Me.OverdueItemsListBox.Name = "OverdueItemsListBox"
        Me.OverdueItemsListBox.Size = New System.Drawing.Size(120, 95)
        Me.OverdueItemsListBox.TabIndex = 26
        '
        'LateFeeTotalTextBox
        '
        Me.LateFeeTotalTextBox.Enabled = False
        Me.LateFeeTotalTextBox.Location = New System.Drawing.Point(128, 39)
        Me.LateFeeTotalTextBox.Name = "LateFeeTotalTextBox"
        Me.LateFeeTotalTextBox.ReadOnly = True
        Me.LateFeeTotalTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LateFeeTotalTextBox.TabIndex = 25
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 39)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(116, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Current Late Fee Total:"
        '
        'MoviesGroupBox
        '
        Me.MoviesGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.MoviesGroupBox.Controls.Add(Me.MovieDueTextBox)
        Me.MoviesGroupBox.Controls.Add(Me.Label1)
        Me.MoviesGroupBox.Controls.Add(Me.MovieCheckOutTextBox)
        Me.MoviesGroupBox.Controls.Add(Me.Label11)
        Me.MoviesGroupBox.Controls.Add(Me.MovieRentedQtyTextBox)
        Me.MoviesGroupBox.Controls.Add(Me.MovieComboBox)
        Me.MoviesGroupBox.Controls.Add(Me.MovieInStockQuantityTextBox)
        Me.MoviesGroupBox.Controls.Add(Me.Label3)
        Me.MoviesGroupBox.Controls.Add(Me.Label2)
        Me.MoviesGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.MoviesGroupBox.Location = New System.Drawing.Point(140, 158)
        Me.MoviesGroupBox.Name = "MoviesGroupBox"
        Me.MoviesGroupBox.Size = New System.Drawing.Size(406, 211)
        Me.MoviesGroupBox.TabIndex = 28
        Me.MoviesGroupBox.TabStop = False
        Me.MoviesGroupBox.Text = "Movies Report"
        '
        'MovieDueTextBox
        '
        Me.MovieDueTextBox.Enabled = False
        Me.MovieDueTextBox.Location = New System.Drawing.Point(299, 108)
        Me.MovieDueTextBox.Name = "MovieDueTextBox"
        Me.MovieDueTextBox.ReadOnly = True
        Me.MovieDueTextBox.Size = New System.Drawing.Size(100, 20)
        Me.MovieDueTextBox.TabIndex = 43
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(203, 111)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 13)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "Due Date:"
        '
        'MovieCheckOutTextBox
        '
        Me.MovieCheckOutTextBox.Location = New System.Drawing.Point(299, 82)
        Me.MovieCheckOutTextBox.Name = "MovieCheckOutTextBox"
        Me.MovieCheckOutTextBox.ReadOnly = True
        Me.MovieCheckOutTextBox.Size = New System.Drawing.Size(100, 20)
        Me.MovieCheckOutTextBox.TabIndex = 41
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(203, 89)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 13)
        Me.Label11.TabIndex = 40
        Me.Label11.Text = "Check-Out Date:"
        '
        'MovieRentedQtyTextBox
        '
        Me.MovieRentedQtyTextBox.Enabled = False
        Me.MovieRentedQtyTextBox.Location = New System.Drawing.Point(299, 56)
        Me.MovieRentedQtyTextBox.Name = "MovieRentedQtyTextBox"
        Me.MovieRentedQtyTextBox.ReadOnly = True
        Me.MovieRentedQtyTextBox.Size = New System.Drawing.Size(100, 20)
        Me.MovieRentedQtyTextBox.TabIndex = 16
        '
        'MovieComboBox
        '
        Me.MovieComboBox.FormattingEnabled = True
        Me.MovieComboBox.Location = New System.Drawing.Point(6, 30)
        Me.MovieComboBox.Name = "MovieComboBox"
        Me.MovieComboBox.Size = New System.Drawing.Size(191, 21)
        Me.MovieComboBox.TabIndex = 24
        Me.MovieComboBox.Text = " (Movie)"
        '
        'MovieInStockQuantityTextBox
        '
        Me.MovieInStockQuantityTextBox.Location = New System.Drawing.Point(299, 30)
        Me.MovieInStockQuantityTextBox.Name = "MovieInStockQuantityTextBox"
        Me.MovieInStockQuantityTextBox.Size = New System.Drawing.Size(100, 20)
        Me.MovieInStockQuantityTextBox.TabIndex = 17
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(203, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "In-Stock Quantity:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(203, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Rented Quantity:"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox2.Location = New System.Drawing.Point(-91, 27)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(63, 22)
        Me.TextBox2.TabIndex = 23
        Me.TextBox2.Text = "Search: "
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.name1
        Me.PictureBox1.Location = New System.Drawing.Point(231, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(743, 114)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'GenreGroupBox
        '
        Me.GenreGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.GenreGroupBox.Controls.Add(Me.GenreInventoryComboBox)
        Me.GenreGroupBox.Controls.Add(Me.InventoryAmountTextBox)
        Me.GenreGroupBox.Controls.Add(Me.Label9)
        Me.GenreGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.GenreGroupBox.Location = New System.Drawing.Point(472, 417)
        Me.GenreGroupBox.Name = "GenreGroupBox"
        Me.GenreGroupBox.Size = New System.Drawing.Size(263, 211)
        Me.GenreGroupBox.TabIndex = 35
        Me.GenreGroupBox.TabStop = False
        Me.GenreGroupBox.Text = "Inventory Report By Genre"
        '
        'GenreInventoryComboBox
        '
        Me.GenreInventoryComboBox.FormattingEnabled = True
        Me.GenreInventoryComboBox.Location = New System.Drawing.Point(6, 31)
        Me.GenreInventoryComboBox.Name = "GenreInventoryComboBox"
        Me.GenreInventoryComboBox.Size = New System.Drawing.Size(155, 21)
        Me.GenreInventoryComboBox.TabIndex = 38
        Me.GenreInventoryComboBox.Text = "(Genre)"
        '
        'InventoryAmountTextBox
        '
        Me.InventoryAmountTextBox.Enabled = False
        Me.InventoryAmountTextBox.Location = New System.Drawing.Point(167, 32)
        Me.InventoryAmountTextBox.Name = "InventoryAmountTextBox"
        Me.InventoryAmountTextBox.ReadOnly = True
        Me.InventoryAmountTextBox.Size = New System.Drawing.Size(90, 20)
        Me.InventoryAmountTextBox.TabIndex = 18
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(164, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 13)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Inventory Amount:"
        '
        'CustomerGroupBox
        '
        Me.CustomerGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.CustomerGroupBox.Controls.Add(Me.Button1)
        Me.CustomerGroupBox.Controls.Add(Me.CustomerComboBox)
        Me.CustomerGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.CustomerGroupBox.Location = New System.Drawing.Point(858, 417)
        Me.CustomerGroupBox.Name = "CustomerGroupBox"
        Me.CustomerGroupBox.Size = New System.Drawing.Size(263, 211)
        Me.CustomerGroupBox.TabIndex = 34
        Me.CustomerGroupBox.TabStop = False
        Me.CustomerGroupBox.Text = "Customer Profile Report"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(95, 166)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "Go!"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'CustomerComboBox
        '
        Me.CustomerComboBox.FormattingEnabled = True
        Me.CustomerComboBox.Location = New System.Drawing.Point(9, 24)
        Me.CustomerComboBox.Name = "CustomerComboBox"
        Me.CustomerComboBox.Size = New System.Drawing.Size(248, 21)
        Me.CustomerComboBox.TabIndex = 25
        Me.CustomerComboBox.Text = "(Name)"
        '
        'VideoGameComboBox
        '
        Me.VideoGameComboBox.FormattingEnabled = True
        Me.VideoGameComboBox.Location = New System.Drawing.Point(20, 33)
        Me.VideoGameComboBox.Name = "VideoGameComboBox"
        Me.VideoGameComboBox.Size = New System.Drawing.Size(177, 21)
        Me.VideoGameComboBox.TabIndex = 37
        Me.VideoGameComboBox.Text = "(Game)"
        '
        'VideoGamesGroupBox
        '
        Me.VideoGamesGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.VideoGamesGroupBox.Controls.Add(Me.GameDueTextBox)
        Me.VideoGamesGroupBox.Controls.Add(Me.Label5)
        Me.VideoGamesGroupBox.Controls.Add(Me.GameCheckOutTextBox)
        Me.VideoGamesGroupBox.Controls.Add(Me.Label6)
        Me.VideoGamesGroupBox.Controls.Add(Me.VideoGameComboBox)
        Me.VideoGamesGroupBox.Controls.Add(Me.GameRentalQtyTextBox)
        Me.VideoGamesGroupBox.Controls.Add(Me.GameInStockTextBox)
        Me.VideoGamesGroupBox.Controls.Add(Me.Label19)
        Me.VideoGamesGroupBox.Controls.Add(Me.Label20)
        Me.VideoGamesGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.VideoGamesGroupBox.Location = New System.Drawing.Point(654, 158)
        Me.VideoGamesGroupBox.Name = "VideoGamesGroupBox"
        Me.VideoGamesGroupBox.Size = New System.Drawing.Size(415, 211)
        Me.VideoGamesGroupBox.TabIndex = 38
        Me.VideoGamesGroupBox.TabStop = False
        Me.VideoGamesGroupBox.Text = "Video Games Report"
        '
        'GameDueTextBox
        '
        Me.GameDueTextBox.Enabled = False
        Me.GameDueTextBox.Location = New System.Drawing.Point(299, 108)
        Me.GameDueTextBox.Name = "GameDueTextBox"
        Me.GameDueTextBox.ReadOnly = True
        Me.GameDueTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GameDueTextBox.TabIndex = 47
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(203, 115)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 46
        Me.Label5.Text = "Due Date:"
        '
        'GameCheckOutTextBox
        '
        Me.GameCheckOutTextBox.Location = New System.Drawing.Point(299, 82)
        Me.GameCheckOutTextBox.Name = "GameCheckOutTextBox"
        Me.GameCheckOutTextBox.ReadOnly = True
        Me.GameCheckOutTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GameCheckOutTextBox.TabIndex = 45
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(203, 89)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 13)
        Me.Label6.TabIndex = 44
        Me.Label6.Text = "Check-Out Date:"
        '
        'GameRentalQtyTextBox
        '
        Me.GameRentalQtyTextBox.Enabled = False
        Me.GameRentalQtyTextBox.Location = New System.Drawing.Point(299, 56)
        Me.GameRentalQtyTextBox.Name = "GameRentalQtyTextBox"
        Me.GameRentalQtyTextBox.ReadOnly = True
        Me.GameRentalQtyTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GameRentalQtyTextBox.TabIndex = 16
        '
        'GameInStockTextBox
        '
        Me.GameInStockTextBox.Location = New System.Drawing.Point(299, 30)
        Me.GameInStockTextBox.Name = "GameInStockTextBox"
        Me.GameInStockTextBox.Size = New System.Drawing.Size(100, 20)
        Me.GameInStockTextBox.TabIndex = 17
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(203, 33)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 13)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "In-Stock Quantity:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(203, 59)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(87, 13)
        Me.Label20.TabIndex = 5
        Me.Label20.Text = "Rented Quantity:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1209, 24)
        Me.MenuStrip1.TabIndex = 40
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Reports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(1209, 664)
        Me.Controls.Add(Me.VideoGamesGroupBox)
        Me.Controls.Add(Me.GenreGroupBox)
        Me.Controls.Add(Me.CustomerGroupBox)
        Me.Controls.Add(Me.LateGroupBox)
        Me.Controls.Add(Me.MoviesGroupBox)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Reports"
        Me.Text = "Reports"
        Me.LateGroupBox.ResumeLayout(False)
        Me.LateGroupBox.PerformLayout()
        Me.MoviesGroupBox.ResumeLayout(False)
        Me.MoviesGroupBox.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GenreGroupBox.ResumeLayout(False)
        Me.GenreGroupBox.PerformLayout()
        Me.CustomerGroupBox.ResumeLayout(False)
        Me.VideoGamesGroupBox.ResumeLayout(False)
        Me.VideoGamesGroupBox.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LateGroupBox As GroupBox
    Friend WithEvents LateFeeTotalTextBox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents MoviesGroupBox As GroupBox
    Friend WithEvents MovieRentedQtyTextBox As TextBox
    Friend WithEvents MovieInStockQuantityTextBox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GenreGroupBox As GroupBox
    Friend WithEvents InventoryAmountTextBox As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents CustomerGroupBox As GroupBox
    Friend WithEvents MovieComboBox As ComboBox
    Friend WithEvents VideoGameComboBox As ComboBox
    Friend WithEvents VideoGamesGroupBox As GroupBox
    Friend WithEvents GameRentalQtyTextBox As TextBox
    Friend WithEvents GameInStockTextBox As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents OverdueItemsListBox As ListBox
    Friend WithEvents CustomerComboBox As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents GenreInventoryComboBox As ComboBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MovieDueTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents MovieCheckOutTextBox As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents GameDueTextBox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents GameCheckOutTextBox As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Button1 As Button
End Class
