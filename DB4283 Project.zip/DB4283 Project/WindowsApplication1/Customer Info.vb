﻿'There will be an update with code for each text box to import Eye Fly's historical data. 
'We hard coded here For presentation purposes To show that it will work In the future.
Public Class Customer_Info

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub ReportsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReportsToolStripMenuItem.Click
        My.Forms.Reports.Show()
        Me.Hide()
    End Sub

    Private Sub HomeToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem1.Click
        My.Forms.Home.Show()
        Me.Hide()
    End Sub

    Private Sub CustomerInfoGroupBox_Enter(sender As Object, e As EventArgs) Handles CustomerInfoGroupBox.Enter

    End Sub
End Class