﻿Public Class POS
    Private TotalEvents As Integer
    Private TotalAmount As Decimal

    'Per day price
    Const ThreeDayMoviePrice = 0.75
    Const FiveDayMoviePrice = 1.25
    Const WeekMoviePrice = 1.5
    Const ThreeDayGamePrice = 1.0
    Const FiveDayGamePrice = 1.5
    Const WeekGamePrice = 2.0
    Const LateMoviePrice = 0.25
    Const LateGamePrice = 0.5
    Private Sub HomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HomeToolStripMenuItem.Click
        My.Forms.Home.Show()
        Me.Hide()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub POS_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        TotalPriceTextBox.Clear()
        LateFeePriceTextBox.Clear()
        LateGameQuantityTextBox.Clear()
        LateMovieQuantityTextBox.Clear()
        MoviePriceTextBox.Clear()
        MovieQuantityTextBox.Clear()
        VideogamePriceTextBox.Clear()
        VideogameQuantityTextBox.Clear()
        DaysLateTextBox.Clear()

        LateGameCheckBox.Checked = False
        LateMovieCheckBox.Checked = False
        ThreeDaymovieRadioButton.Checked = False
        ThreeDayVideogameRadioButton.Checked = False
        FivedaymovieRadioButton.Checked = False
        FivedayvideogameRadioButton.Checked = False
        OneweekmovieButton.Checked = False
        OneWeekvideogameRadioButton.Checked = False

        MovieQuantityTextBox.Focus()

    End Sub

    Private Sub CalculateButton_Click(sender As Object, e As EventArgs) Handles CalculateButton.Click
        Dim MovieOrderQtyDecimal As Decimal
        Dim GameOrderQtyDecimal As Decimal
        Dim LateMovieOrderQtyDecimal As Decimal
        Dim LateGameOrderQtyDecimal As Decimal
        Dim DaysLateDecimal As Decimal
        Dim TotalAmount As Decimal
        Dim AmountDueDecimal As Decimal

        Try
            MovieOrderQtyDecimal = Decimal.Parse(MovieQuantityTextBox.Text)
            GameOrderQtyDecimal = Decimal.Parse(VideogameQuantityTextBox.Text)
            LateMovieOrderQtyDecimal = Decimal.Parse(LateMovieQuantityTextBox.Text)
            LateGameOrderQtyDecimal = Decimal.Parse(LateGameQuantityTextBox.Text)
            DaysLateDecimal = Decimal.Parse(DaysLateTextBox.Text)

            'Calculation for movie checkout
            If ThreeDaymovieRadioButton.Checked Then
                AmountDueDecimal = (MovieOrderQtyDecimal * ThreeDayMoviePrice)
                TotalAmount += AmountDueDecimal
            ElseIf FivedayvideogameRadioButton.Checked Then
                AmountDueDecimal = (MovieOrderQtyDecimal * FiveDayMoviePrice)
                TotalAmount += AmountDueDecimal
            ElseIf OneWeekvideogameRadioButton.Checked Then
                AmountDueDecimal = (MovieOrderQtyDecimal * WeekMoviePrice)
                TotalAmount += AmountDueDecimal
            Else


            End If

            MoviePriceTextBox.Text = AmountDueDecimal.ToString("C")


            'Calculation for game checkout
            If ThreeDayVideogameRadioButton.Checked Then
                AmountDueDecimal = (GameOrderQtyDecimal * ThreeDayGamePrice)
                TotalAmount += AmountDueDecimal
            ElseIf FivedayvideogameRadioButton.Checked Then
                AmountDueDecimal = (GameOrderQtyDecimal * FiveDayGamePrice)
                TotalAmount += AmountDueDecimal
            ElseIf OneWeekvideogameRadioButton.Checked Then
                AmountDueDecimal = (GameOrderQtyDecimal * WeekGamePrice)
                TotalAmount += AmountDueDecimal
            Else


            End If

            VideogamePriceTextBox.Text = AmountDueDecimal.ToString("C")


            'Calculation for late fees
            If LateMovieCheckBox.Checked Then
                AmountDueDecimal = (LateMovieOrderQtyDecimal * LateMoviePrice) * DaysLateDecimal
                TotalAmount += AmountDueDecimal
            ElseIf LateGameCheckBox.Checked Then
                AmountDueDecimal = (LateGameOrderQtyDecimal * LateGamePrice) * DaysLateDecimal
                TotalAmount += AmountDueDecimal
            Else


            End If

            LateFeePriceTextBox.Text = AmountDueDecimal.ToString("C")

            If LateGameCheckBox.Checked = False And LateMovieCheckBox.Checked And
               ThreeDaymovieRadioButton.Checked = False And FivedaymovieRadioButton.Checked = False And OneweekmovieButton.Checked = False And
                ThreeDayVideogameRadioButton.Checked = False And FivedayvideogameRadioButton.Checked = False And OneWeekvideogameRadioButton.Checked = False Then
                MessageBox.Show("Please make a selection.", "Input Needed",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            'adds up all group boxes and displays them in total amount
            TotalPriceTextBox.Text = TotalAmount.ToString("C")

            If TotalAmount <= 0 Then
                TotalPriceTextBox.Text = ""
            End If

        Catch
            MessageBox.Show("Order Quantity must be numeric.", "Data Entry Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            MovieQuantityTextBox.Focus()
        End Try


    End Sub
End Class