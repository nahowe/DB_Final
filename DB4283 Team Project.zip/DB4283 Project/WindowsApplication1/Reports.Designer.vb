﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Reports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DessertsGroupBox = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.OverdueItemsListBox = New System.Windows.Forms.ListBox()
        Me.LateFeeTotalTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SaladsGroupBox = New System.Windows.Forms.GroupBox()
        Me.SaladPriceTextBox = New System.Windows.Forms.TextBox()
        Me.MovieComboBox = New System.Windows.Forms.ComboBox()
        Me.SaladQuantityTextBox = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GenreInventoryComboBox = New System.Windows.Forms.ComboBox()
        Me.InventoryAmountTextBox = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.MonthComboBox = New System.Windows.Forms.ComboBox()
        Me.WeekComboBox = New System.Windows.Forms.ComboBox()
        Me.MonthlySalesTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.WeeklySalesTextBox = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.PreviousRentalComboBox = New System.Windows.Forms.ComboBox()
        Me.CustomerProfileTextBox = New System.Windows.Forms.TextBox()
        Me.TotalAmountSpentTextBox = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.VideoGameComboBox = New System.Windows.Forms.ComboBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DessertsGroupBox.SuspendLayout()
        Me.SaladsGroupBox.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DessertsGroupBox
        '
        Me.DessertsGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.DessertsGroupBox.Controls.Add(Me.Label4)
        Me.DessertsGroupBox.Controls.Add(Me.OverdueItemsListBox)
        Me.DessertsGroupBox.Controls.Add(Me.LateFeeTotalTextBox)
        Me.DessertsGroupBox.Controls.Add(Me.Label8)
        Me.DessertsGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.DessertsGroupBox.Location = New System.Drawing.Point(312, 349)
        Me.DessertsGroupBox.Name = "DessertsGroupBox"
        Me.DessertsGroupBox.Size = New System.Drawing.Size(263, 277)
        Me.DessertsGroupBox.TabIndex = 30
        Me.DessertsGroupBox.TabStop = False
        Me.DessertsGroupBox.Text = "Overdue Items/Late Fees Report"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 94)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 13)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Current Overdue Items:"
        '
        'OverdueItemsListBox
        '
        Me.OverdueItemsListBox.FormattingEnabled = True
        Me.OverdueItemsListBox.Location = New System.Drawing.Point(128, 94)
        Me.OverdueItemsListBox.Name = "OverdueItemsListBox"
        Me.OverdueItemsListBox.Size = New System.Drawing.Size(120, 95)
        Me.OverdueItemsListBox.TabIndex = 26
        '
        'LateFeeTotalTextBox
        '
        Me.LateFeeTotalTextBox.Enabled = False
        Me.LateFeeTotalTextBox.Location = New System.Drawing.Point(128, 39)
        Me.LateFeeTotalTextBox.Name = "LateFeeTotalTextBox"
        Me.LateFeeTotalTextBox.ReadOnly = True
        Me.LateFeeTotalTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LateFeeTotalTextBox.TabIndex = 25
        Me.LateFeeTotalTextBox.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 39)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(116, 13)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Current Late Fee Total:"
        '
        'SaladsGroupBox
        '
        Me.SaladsGroupBox.BackColor = System.Drawing.SystemColors.GrayText
        Me.SaladsGroupBox.Controls.Add(Me.SaladPriceTextBox)
        Me.SaladsGroupBox.Controls.Add(Me.MovieComboBox)
        Me.SaladsGroupBox.Controls.Add(Me.SaladQuantityTextBox)
        Me.SaladsGroupBox.Controls.Add(Me.Label3)
        Me.SaladsGroupBox.Controls.Add(Me.Label2)
        Me.SaladsGroupBox.ForeColor = System.Drawing.Color.LightGreen
        Me.SaladsGroupBox.Location = New System.Drawing.Point(168, 132)
        Me.SaladsGroupBox.Name = "SaladsGroupBox"
        Me.SaladsGroupBox.Size = New System.Drawing.Size(406, 211)
        Me.SaladsGroupBox.TabIndex = 28
        Me.SaladsGroupBox.TabStop = False
        Me.SaladsGroupBox.Text = "Movies Report (By actor for now)"
        '
        'SaladPriceTextBox
        '
        Me.SaladPriceTextBox.Enabled = False
        Me.SaladPriceTextBox.Location = New System.Drawing.Point(299, 76)
        Me.SaladPriceTextBox.Name = "SaladPriceTextBox"
        Me.SaladPriceTextBox.ReadOnly = True
        Me.SaladPriceTextBox.Size = New System.Drawing.Size(100, 20)
        Me.SaladPriceTextBox.TabIndex = 16
        Me.SaladPriceTextBox.Text = "0"
        '
        'MovieComboBox
        '
        Me.MovieComboBox.FormattingEnabled = True
        Me.MovieComboBox.Location = New System.Drawing.Point(6, 30)
        Me.MovieComboBox.Name = "MovieComboBox"
        Me.MovieComboBox.Size = New System.Drawing.Size(191, 21)
        Me.MovieComboBox.TabIndex = 24
        Me.MovieComboBox.Text = "(Name, Genre, Director, or Actor)"
        '
        'SaladQuantityTextBox
        '
        Me.SaladQuantityTextBox.Location = New System.Drawing.Point(299, 30)
        Me.SaladQuantityTextBox.Name = "SaladQuantityTextBox"
        Me.SaladQuantityTextBox.Size = New System.Drawing.Size(100, 20)
        Me.SaladQuantityTextBox.TabIndex = 17
        Me.SaladQuantityTextBox.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(203, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "In-Stock Quantity:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(203, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Rented Quantity:"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox2.Location = New System.Drawing.Point(-91, 27)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(63, 22)
        Me.TextBox2.TabIndex = 23
        Me.TextBox2.Text = "Search: "
        '
        'TextBox1
        '
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(68, 27)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(157, 22)
        Me.TextBox1.TabIndex = 22
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication1.My.Resources.Resources.name1
        Me.PictureBox1.Location = New System.Drawing.Point(213, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(743, 114)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox5.Location = New System.Drawing.Point(-1, 27)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(63, 22)
        Me.TextBox5.TabIndex = 33
        Me.TextBox5.Text = "Search: "
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.GrayText
        Me.GroupBox1.Controls.Add(Me.GenreInventoryComboBox)
        Me.GroupBox1.Controls.Add(Me.InventoryAmountTextBox)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.ForeColor = System.Drawing.Color.LightGreen
        Me.GroupBox1.Location = New System.Drawing.Point(612, 349)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(263, 277)
        Me.GroupBox1.TabIndex = 35
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Inventory Report By Genre"
        '
        'GenreInventoryComboBox
        '
        Me.GenreInventoryComboBox.FormattingEnabled = True
        Me.GenreInventoryComboBox.Location = New System.Drawing.Point(6, 31)
        Me.GenreInventoryComboBox.Name = "GenreInventoryComboBox"
        Me.GenreInventoryComboBox.Size = New System.Drawing.Size(155, 21)
        Me.GenreInventoryComboBox.TabIndex = 38
        Me.GenreInventoryComboBox.Text = "(Genre)"
        '
        'InventoryAmountTextBox
        '
        Me.InventoryAmountTextBox.Enabled = False
        Me.InventoryAmountTextBox.Location = New System.Drawing.Point(167, 32)
        Me.InventoryAmountTextBox.Name = "InventoryAmountTextBox"
        Me.InventoryAmountTextBox.ReadOnly = True
        Me.InventoryAmountTextBox.Size = New System.Drawing.Size(90, 20)
        Me.InventoryAmountTextBox.TabIndex = 18
        Me.InventoryAmountTextBox.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(164, 16)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 13)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Inventory Amount:"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.GrayText
        Me.GroupBox2.Controls.Add(Me.MonthComboBox)
        Me.GroupBox2.Controls.Add(Me.WeekComboBox)
        Me.GroupBox2.Controls.Add(Me.MonthlySalesTextBox)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.WeeklySalesTextBox)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.ForeColor = System.Drawing.Color.LightGreen
        Me.GroupBox2.Location = New System.Drawing.Point(912, 349)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(263, 277)
        Me.GroupBox2.TabIndex = 36
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Sales Summary Report"
        '
        'MonthComboBox
        '
        Me.MonthComboBox.FormattingEnabled = True
        Me.MonthComboBox.Location = New System.Drawing.Point(119, 96)
        Me.MonthComboBox.Name = "MonthComboBox"
        Me.MonthComboBox.Size = New System.Drawing.Size(138, 21)
        Me.MonthComboBox.TabIndex = 40
        Me.MonthComboBox.Text = "(Month)"
        '
        'WeekComboBox
        '
        Me.WeekComboBox.FormattingEnabled = True
        Me.WeekComboBox.Location = New System.Drawing.Point(119, 29)
        Me.WeekComboBox.Name = "WeekComboBox"
        Me.WeekComboBox.Size = New System.Drawing.Size(138, 21)
        Me.WeekComboBox.TabIndex = 39
        Me.WeekComboBox.Text = "(Week)"
        '
        'MonthlySalesTextBox
        '
        Me.MonthlySalesTextBox.Enabled = False
        Me.MonthlySalesTextBox.Location = New System.Drawing.Point(119, 129)
        Me.MonthlySalesTextBox.Name = "MonthlySalesTextBox"
        Me.MonthlySalesTextBox.ReadOnly = True
        Me.MonthlySalesTextBox.Size = New System.Drawing.Size(138, 20)
        Me.MonthlySalesTextBox.TabIndex = 27
        Me.MonthlySalesTextBox.Text = "0"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 129)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Monthly Sales:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 99)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(40, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Month:"
        '
        'WeeklySalesTextBox
        '
        Me.WeeklySalesTextBox.Location = New System.Drawing.Point(119, 65)
        Me.WeeklySalesTextBox.Name = "WeeklySalesTextBox"
        Me.WeeklySalesTextBox.ReadOnly = True
        Me.WeeklySalesTextBox.Size = New System.Drawing.Size(138, 20)
        Me.WeeklySalesTextBox.TabIndex = 21
        Me.WeeklySalesTextBox.Text = "0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 68)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(75, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Weekly Sales:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 32)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(95, 13)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "Week (day range):"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.SystemColors.GrayText
        Me.GroupBox3.Controls.Add(Me.PreviousRentalComboBox)
        Me.GroupBox3.Controls.Add(Me.CustomerProfileTextBox)
        Me.GroupBox3.Controls.Add(Me.TotalAmountSpentTextBox)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.ForeColor = System.Drawing.Color.LightGreen
        Me.GroupBox3.Location = New System.Drawing.Point(12, 349)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(263, 277)
        Me.GroupBox3.TabIndex = 34
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Customer Profile Report"
        '
        'PreviousRentalComboBox
        '
        Me.PreviousRentalComboBox.FormattingEnabled = True
        Me.PreviousRentalComboBox.Location = New System.Drawing.Point(9, 24)
        Me.PreviousRentalComboBox.Name = "PreviousRentalComboBox"
        Me.PreviousRentalComboBox.Size = New System.Drawing.Size(138, 21)
        Me.PreviousRentalComboBox.TabIndex = 25
        '
        'CustomerProfileTextBox
        '
        Me.CustomerProfileTextBox.Location = New System.Drawing.Point(156, 112)
        Me.CustomerProfileTextBox.Name = "CustomerProfileTextBox"
        Me.CustomerProfileTextBox.Size = New System.Drawing.Size(101, 20)
        Me.CustomerProfileTextBox.TabIndex = 18
        '
        'TotalAmountSpentTextBox
        '
        Me.TotalAmountSpentTextBox.Enabled = False
        Me.TotalAmountSpentTextBox.Location = New System.Drawing.Point(156, 51)
        Me.TotalAmountSpentTextBox.Name = "TotalAmountSpentTextBox"
        Me.TotalAmountSpentTextBox.ReadOnly = True
        Me.TotalAmountSpentTextBox.Size = New System.Drawing.Size(101, 20)
        Me.TotalAmountSpentTextBox.TabIndex = 16
        Me.TotalAmountSpentTextBox.Text = "0"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(153, 85)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 13)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Previous Rentals:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(153, 27)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(104, 13)
        Me.Label14.TabIndex = 5
        Me.Label14.Text = "Total Amount Spent:"
        '
        'VideoGameComboBox
        '
        Me.VideoGameComboBox.FormattingEnabled = True
        Me.VideoGameComboBox.Location = New System.Drawing.Point(20, 33)
        Me.VideoGameComboBox.Name = "VideoGameComboBox"
        Me.VideoGameComboBox.Size = New System.Drawing.Size(177, 21)
        Me.VideoGameComboBox.TabIndex = 37
        Me.VideoGameComboBox.Text = "(Name)"
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.SystemColors.GrayText
        Me.GroupBox4.Controls.Add(Me.VideoGameComboBox)
        Me.GroupBox4.Controls.Add(Me.TextBox16)
        Me.GroupBox4.Controls.Add(Me.TextBox17)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.ForeColor = System.Drawing.Color.LightGreen
        Me.GroupBox4.Location = New System.Drawing.Point(612, 132)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(415, 211)
        Me.GroupBox4.TabIndex = 38
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Video Games Report"
        '
        'TextBox16
        '
        Me.TextBox16.Enabled = False
        Me.TextBox16.Location = New System.Drawing.Point(299, 76)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.ReadOnly = True
        Me.TextBox16.Size = New System.Drawing.Size(100, 20)
        Me.TextBox16.TabIndex = 16
        Me.TextBox16.Text = "0"
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(299, 30)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(100, 20)
        Me.TextBox17.TabIndex = 17
        Me.TextBox17.Text = "0"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(203, 33)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 13)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "In-Stock Quantity:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(203, 79)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(87, 13)
        Me.Label20.TabIndex = 5
        Me.Label20.Text = "Rented Quantity:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1209, 24)
        Me.MenuStrip1.TabIndex = 40
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HomeToolStripMenuItem
        '
        Me.HomeToolStripMenuItem.Name = "HomeToolStripMenuItem"
        Me.HomeToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.HomeToolStripMenuItem.Text = "Home"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Reports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(1209, 664)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.DessertsGroupBox)
        Me.Controls.Add(Me.SaladsGroupBox)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Reports"
        Me.Text = "Reports"
        Me.DessertsGroupBox.ResumeLayout(False)
        Me.DessertsGroupBox.PerformLayout()
        Me.SaladsGroupBox.ResumeLayout(False)
        Me.SaladsGroupBox.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DessertsGroupBox As GroupBox
    Friend WithEvents LateFeeTotalTextBox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents SaladsGroupBox As GroupBox
    Friend WithEvents SaladPriceTextBox As TextBox
    Friend WithEvents SaladQuantityTextBox As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents InventoryAmountTextBox As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label10 As Label
    Friend WithEvents WeeklySalesTextBox As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents TotalAmountSpentTextBox As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents MovieComboBox As ComboBox
    Friend WithEvents VideoGameComboBox As ComboBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents OverdueItemsListBox As ListBox
    Friend WithEvents PreviousRentalComboBox As ComboBox
    Friend WithEvents CustomerProfileTextBox As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents MonthlySalesTextBox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents MonthComboBox As ComboBox
    Friend WithEvents WeekComboBox As ComboBox
    Friend WithEvents GenreInventoryComboBox As ComboBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HomeToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
End Class
